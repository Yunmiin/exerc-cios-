#include <stdio.h>

int main()
{
   
 int temps1, idade;
 printf("Informe o tempo que foi trabalhado: ");
 scanf("%i",&temps1);
 
 printf("Informe sua idade: ");
 scanf("%i",&idade);
 
 
 if(idade >= 65 || temps1 >= 30 ){
     printf("Você poderá se aposentar!");
 } 
 else if (idade >= 60 && temps1 >= 25  ){
         printf("Você poderá se aposentar!");
     
    } else{
         printf("Você não poderá se aposentar");
         
     }
 
}