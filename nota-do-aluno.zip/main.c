#include <stdio.h>

int main(void)
{
  int nota1, nota2, media;
  

  printf("Digite a nota 1 do aluno: ");
  scanf("%i",&nota1);
  
  printf("Digite a nota 2 do aluno: ");
  scanf("%i",&nota2);
  
  media = (nota1 + nota2) / 2;
  
  printf("Média do aluno = %i\n",media);
  
  if(media >= 7){
      printf("Aprovado!");
      
  }
  else if(media >= 4 && media <= 5){
      printf("Exame!");
      
  }
  else{
      printf("Reprovado!");
  }
}