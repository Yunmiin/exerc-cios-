#include <stdio.h>

int main(void)
{ 
    int n1;
    printf("Digite um numero: \n");
    scanf("%i",&n1);
    
   
    printf("%i X 1 = %i\n",n1 , n1 * 1);
    printf("%i X 2 = %i\n",n1 , n1 * 2);
    printf("%i X 3 = %i\n",n1 , n1 * 3);
    printf("%i X 4 = %i\n",n1 , n1 * 4);
    printf("%i X 5 = %i\n",n1 , n1 * 5);
    printf("%i X 6 = %i\n",n1 , n1 * 6);
    printf("%i X 7 = %i\n",n1 , n1 * 7);
    printf("%i X 8 = %i\n",n1 , n1 * 8);
    printf("%i X 9 = %i\n",n1 , n1 * 9);
    printf("%i X 10 =%i\n",n1 , n1 * 10);
   
}